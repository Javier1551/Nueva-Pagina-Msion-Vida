import { getAuth, signInWithPopup, GoogleAuthProvider, FacebookAuthProvider, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-auth.js";

const auth = getAuth();
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });
const facebookProvider = new FacebookAuthProvider();

// Función para mostrar mensajes
function showMessage(message, type = 'info') {
  const messageContainer = document.getElementById('messageContainer');
  messageContainer.textContent = message;
  messageContainer.className = `alert alert-${type} fade-in`;
  messageContainer.style.display = 'block';

  setTimeout(() => {
    messageContainer.style.display = 'none';
  }, 3000);
}

document.getElementById('googleLogin').addEventListener('click', () => {
  signInWithPopup(auth, googleProvider)
    .then((result) => {
      console.log("Usuario con Google: ", result.user);
      showMessage(`¡Bienvenido, ${result.user.displayName}!`, 'success');
      $('#authModal').modal('hide');
    })
    .catch((error) => {
      console.error("Error al iniciar sesión con Google: ", error);
      showMessage("Error al iniciar sesión con Google.", 'danger');
    });
});

document.getElementById('facebookLogin').addEventListener('click', () => {
  signInWithPopup(auth, facebookProvider)
    .then((result) => {
      console.log("Usuario con Facebook: ", result.user);
      showMessage(`¡Bienvenido, ${result.user.displayName}!`, 'success');
      $('#authModal').modal('hide');
    })
    .catch((error) => {
      console.error("Error al iniciar sesión con Facebook: ", error);
      showMessage("Error al iniciar sesión con Facebook.", 'danger');
    });
});

document.getElementById('showEmailLogin').addEventListener('click', () => {
  $('#authModal').modal('hide');
  $('#secondaryModal').modal('show');
  $('#secondaryModalLabel').text('Iniciar Sesión con Email');
  $('#emailForm').show();
  $('#registerForm').hide();
});

document.getElementById('showRegister').addEventListener('click', () => {
  $('#authModal').modal('hide');
  $('#secondaryModal').modal('show');
  $('#secondaryModalLabel').text('Registrarse');
  $('#registerForm').show();
  $('#emailForm').hide();
});

document.getElementById('emailLogin').addEventListener('click', () => {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      console.log("Usuario con Email: ", userCredential.user);
      showMessage(`¡Bienvenido, ${userCredential.user.email}!`, 'success');
      $('#secondaryModal').modal('hide');
    })
    .catch((error) => {
      console.error("Error al iniciar sesión con Email: ", error);
      if (error.code === 'auth/user-not-found') {
        showMessage("Usuario no encontrado.", 'danger');
      } else if (error.code === 'auth/wrong-password') {
        showMessage("Contraseña incorrecta.", 'danger');
      } else {
        showMessage("Error al iniciar sesión con Email.", 'danger');
      }
    });
});

document.getElementById('registerUser').addEventListener('click', () => {
  const email = document.getElementById('registerEmail').value;
  const password = document.getElementById('registerPassword').value;

  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      console.log("Usuario registrado: ", userCredential.user);
      showMessage(`¡Registro exitoso, ${userCredential.user.email}!`, 'success');
      $('#secondaryModal').modal('hide');
    })
    .catch((error) => {
      console.error("Error al registrarse: ", error);
      if (error.code === 'auth/email-already-in-use') {
        showMessage("El email ya está registrado.", 'danger');
      } else if (error.code === 'auth/weak-password') {
        showMessage("La contraseña es muy débil.", 'danger');
      } else {
        showMessage("Error al registrarse.", 'danger');
      }
    });
});

document.getElementById('logout').addEventListener('click', () => {
  signOut(auth).then(() => {
    console.log('Sesión cerrada exitosamente');
    showMessage('Sesión cerrada exitosamente.', 'success');
  }).catch((error) => {
    console.error('Error al cerrar sesión:', error);
    showMessage('Error al cerrar sesión.', 'danger');
  });
});
