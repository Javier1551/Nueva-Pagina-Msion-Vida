// firebase-config.js

// Importar las funciones necesarias desde los SDKs que necesitas
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-analytics.js";
// Importar otras funciones de Firebase que puedas necesitar (Auth, Firestore, etc.)

// Configuración de Firebase de tu aplicación web
const firebaseConfig = {
  apiKey: "AIzaSyCsO5hXO3fprE66Wl1ubjtzXUUC-rOL5xA",
  authDomain: "fundacion-mision-vida.firebaseapp.com",
  databaseURL: "https://fundacion-mision-vida-default-rtdb.firebaseio.com",
  projectId: "fundacion-mision-vida",
  storageBucket: "fundacion-mision-vida.appspot.com",
  messagingSenderId: "883747728334",
  appId: "1:883747728334:web:323b9ab9ef308cb5eb599f",
  measurementId: "G-G34X3J5Q91"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

